﻿CREATE PROCEDURE [dbo].[sp_insert]  
(  
    -- Add the parameters for the stored procedure here  
  
      
    @Username varchar(50),  
    @Password varchar(50),  
    @Email varchar(50)  
  
)  
as  
Begin  
  
    Declare @Count int  
    Declare @codereturn int  
      
    Select @Count = COUNT(Username)  
    from Users where Username = @Username  
    If @Count > 0  
    Begin   
      
        Set @codereturn = -1  
    End  
    Else  
    Begin  
          
        Set @codereturn  = 1  
        Insert into Users values(@Username,@Password,@Email)  
      
    End  
    Select @codereturn as ReturnValue  
      
End   
